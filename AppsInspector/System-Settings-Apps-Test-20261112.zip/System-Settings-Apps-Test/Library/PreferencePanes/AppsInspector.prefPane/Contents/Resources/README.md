# Apps Inspector registration experiment

On macOS 27.2 (26B123), an ad-hoc signed arm64 Debug build installed in
`~/Library/PreferencePanes/AppsInspector.prefPane` appeared in System Settings.
The user-provided screenshot shows the prototype view loaded. Its process name
was `legacyLoader-arm64`; the running process was observed at
`/System/Library/Frameworks/PreferencePanes.framework/Versions/A/XPCServices/legacyLoader-arm64.xpc/Contents/MacOS/legacyLoader-arm64`.
The screenshot's `Bundle.main` executable value was `/System Settings`; it is
not sufficient to identify the process executable.

System Settings resized its window to fit the prototype; the user reported that
manual resizing was unavailable while the pane was selected and worked again
after selecting a different settings category. Selecting Apps Inspector changed
the window size again. Screenshots show a blank content area after the initial
successful display, but do not establish the cause.
Selection after deselection, sizing behavior, host sandbox and effective
entitlements, App Group access, SQLite sharing and security-scoped bookmark
sharing remain unverified. This experiment is not the production interface.

An unsigned universal arm64/x86_64 Debug build also compiled successfully.
The installed arm64 proof uses an ad-hoc signature; this does not establish
Developer ID distribution or notarization support.
