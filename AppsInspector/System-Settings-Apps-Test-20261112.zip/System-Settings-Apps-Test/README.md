# System Settings Apps — Test Package

The application and preference pane are signed with a **Developer ID Application** certificate and include secure timestamps. Notarization and Gatekeeper testing have not been performed.

### Installation

**Recommended: User-level installation**

1. Copy **System Settings Apps.app** to `~/Applications`.
2. Copy **AppsInspector.prefPane** from `Library/PreferencePanes/` to `~/Library/PreferencePanes`.
3. Open the application or preference pane as needed.

**Alternative: System-wide installation**

If the user-level installation does not work, you can also try:

1. Copy **System Settings Apps.app** to `/Applications`.
2. Copy **AppsInspector.prefPane** to `/Library/PreferencePanes`.

System-wide installation may require administrator privileges.

### Package Contents

- **System Settings Apps.app** — Application to be copied to `~/Applications` or, alternatively, `/Applications`.
- **Library/PreferencePanes/AppsInspector.prefPane** — Signed preference pane for manual installation. Copy it to `~/Library/PreferencePanes` or, alternatively, `/Library/PreferencePanes`. The `Library` directory included in this package is part of the package contents, not a system installation directory.
- **AppsInspector-Install-UNSIGNED.pkg** — Optional installer that places the preference pane in `/Library/PreferencePanes`. Administrator privileges are required. The PKG itself is unsigned because no Developer ID Installer certificate is available.

### Experimental Status

The preference pane's contents may disappear after switching sections in System Settings.

The installer has not been executed, and functionality after installation has not been verified. Notarization and Gatekeeper testing have not been performed.